const express = require('express');
const router = express.Router();
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: 'smtp.mkm.net.br',
  port: 587,
  secure: false, 
  auth: {
    user: 'guilhermeroecker@mkm.net.br',
    pass: ''
  },
  tls: {
    rejectUnauthorized: false 
  }
});


router.post('/', async (req, res) => {
  const { nome, email, mensagem } = req.body;

  try {
    const info = await transporter.sendMail({
      from: '"Contato do Site" <guilhermeroecker@mkm.net.br>',
      to: email,
      subject: 'Nova mensagem do site',
      html: `
        <p><strong>Nome:</strong> ${nome}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Mensagem:</strong> ${mensagem}</p>
      `
    });

    console.log('E-mail enviado:', info.messageId);
    res.json({ mensagem: 'E-mail enviado com sucesso!' });
  } catch (err) {
    console.error('Erro ao enviar e-mail:', err);
    res.status(500).json({ mensagem: 'Erro ao enviar e-mail.' });
  }
});

module.exports = router;